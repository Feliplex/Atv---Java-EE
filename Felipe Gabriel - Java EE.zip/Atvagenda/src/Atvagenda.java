
public class Atvagenda {
	public static void main (String[] args) {
		BancoDeDados bancoDeDados = new BancoDeDados();
		bancoDeDados.conectar();
		if(bancoDeDados.estaConectado()) {
			bancoDeDados.listarContatos();
			//bancoDeDados.inserirContato("Jose","Buritizal");
			//bancoDeDados.editarContato("1", "Rafa", "Marabaixo");
			//bancoDeDados.apagarContato("1");
			bancoDeDados.desconectar();
		} else {
			System.out.println("N�o foi poss�vel se conectar nessa desgra�a de banco de dados!");
		}
	}
}
